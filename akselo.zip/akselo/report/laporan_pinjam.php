<?php
include "../inc/koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title></title>
</head>

<table border="0" cellspacing="0" style="width: 100%">
	<tbody>
		<tr>
			<td align="right">
				<img src="../dist/img/xx.png" width="140px">
			</td>
			<td>
				<h2>TCSM INVENTORY SYSTEM</h2>
				<b>Depo MRT Lebak Bulus, Jakarta Selatan</b>
			</td>
		</tr>
	</tbody>
</table>

<body>
	<center>
		<hr / size="2px" color="black">
		<h3>DATA PEMINJAMAN ALAT
		</h3>
		Tanggal Cetak :
		<?php echo date('d/m/Y'); ?>

		<table border="1" cellspacing="0" style="width: 100%">
			<thead>
				<tr>
					<th>No</th>
					<th>Alat</th>
					<th>Peminjam</th>
					<th>Tgl Peminjaman</th>
				</tr>
			</thead>
			<tbody>
				<?php
                  $no = 1;
                  $sql = $koneksi->query("SELECT b.inventori_id, a.nik, a.nama, l.tgl_pinjam
                  from log_pinjam l inner join tb_alat b on l.id_alat=b.id_alat
				  inner join tb_tim a on l.nik=a.nik order by tgl_pinjam asc");
                  while ($data= $sql->fetch_assoc()) {
                ?>
				<tr>
					<td>
						<?php echo $no++; ?>
					</td>
					<td>
						<?php echo $data['inventori_id']; ?>
					</td>
					<td>
						<?php echo $data['nik']; ?>
						-
						<?php echo $data['nama']; ?>
					</td>
					<td>
						<?php  $tgl = $data['tgl_pinjam']; echo date("d/M/Y", strtotime($tgl))?>
					</td>
				</tr>
				<?php
            }
        ?>
			</tbody>
		</table>
	</center>

	<script>
		window.print();
	</script>
</body>

</html>