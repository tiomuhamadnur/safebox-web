 <section class="content-header">
	<h1>
		Master Data
		<small>Data Alat</small>
	</h1>
	<ol class="breadcrumb">
		<li>
			<a href="index.php">
				<i class="fa fa-home"></i>
				<b>TCSM Inventory System</b>
			</a>
		</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-md-12">
			<!-- general form elements -->
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Tambah Alat</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse">
							<i class="fa fa-minus"></i>
						</button>
						<button type="button" class="btn btn-box-tool" data-widget="remove">
							<i class="fa fa-remove"></i>
						</button>
					</div>
				</div>
				<!-- /.box-header -->
				<!-- form start -->
				<form action="" method="post" enctype="multipart/form-data">
					<div class="box-body">

						<div class="form-group">
							<label>Inv ID</label>
							<input type="text" name="inventori_id" id="inventori_id" class="form-control" placeholder="Inventory ID">
						</div>

						<div class="form-group">
							<label>Nama Alat</label>
							<input type="text" name="nama_alat" id="nama_alat" class="form-control" placeholder="Nama Alat">
						</div>

						<div class="form-group">
							<label>Owning</label>
							<input type="text" name="owning" id="owning" class="form-control" placeholder="Owning">
						</div>

						<div class="form-group">
							<label>Lokasi</label>
							<input type="text" name="lokasi" id="lokasi" class="form-control" placeholder="Lokasi">
						</div>

						<div class="form-group">
							<label>Jumlah</label>
							<input type="number" name="jumlah" id="jumlah" class="form-control" placeholder="Jumlah">
						</div>

						<div class="form-group">
							<label>Tgl Input</label>
							<input type="date" name="tgl_input" id="tgl_input" class="form-control">
						</div>

					</div>
					<!-- /.box-body -->

					<div class="box-footer">
						<input type="submit" name="Simpan" value="Simpan" class="btn btn-info">
						<a href="?page=MyApp/data_alat" class="btn btn-warning">Batal</a>
					</div>
				</form>
			</div>
			<!-- /.box -->
</section>

<?php

    if (isset ($_POST['Simpan'])){
    
        $sql_simpan = "INSERT INTO tb_alat (inventori_id,nama_alat,owning,lokasi,jumlah,tgl_input) VALUES (
          '".$_POST['inventori_id']."',
          '".$_POST['nama_alat']."',
		  '".$_POST['owning']."',
		  '".$_POST['lokasi']."',
		  '".$_POST['jumlah']."',
          '".$_POST['tgl_input']."')";
        $query_simpan = mysqli_query($koneksi, $sql_simpan);
        mysqli_close($koneksi);

    if ($query_simpan){

      echo "<script>
      Swal.fire({title: 'Tambah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
      }).then((result) => {
          if (result.value) {
              window.location = 'index.php?page=MyApp/data_alat';
          }
      })</script>";
      }else{
      echo "<script>
      Swal.fire({title: 'Tambah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
      }).then((result) => {
          if (result.value) {
              window.location = 'index.php?page=MyApp/add_alat';
          }
      })</script>";
    }
  }
    
