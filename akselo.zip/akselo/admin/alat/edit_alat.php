<?php

    if(isset($_GET['kode'])){
        $sql_cek = "SELECT * FROM tb_alat WHERE id_alat='".$_GET['kode']."'";
        $query_cek = mysqli_query($koneksi, $sql_cek);
        $data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
    }
?>

<section class="content-header">
	<h1>
		Master Data
		<small>Data Alat</small>
	</h1>
	<ol class="breadcrumb">
		<li>
			<a href="index.php">
				<i class="fa fa-home"></i>
				<b>TCSM Inventory System</b>
			</a>
		</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-md-12">
			<!-- general form elements -->
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Ubah Alat</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse">
							<i class="fa fa-minus"></i>
						</button>
						<button type="button" class="btn btn-box-tool" data-widget="remove">
							<i class="fa fa-remove"></i>
						</button>
					</div>
				</div>
				<!-- /.box-header -->
				<!-- form start -->
				<form action="" method="post" enctype="multipart/form-data">
					<div class="box-body">

						<input type='hidden' class="form-control" name="id_alat" value="<?php echo $data_cek['id_alat']; ?>"
						 readonly/>

						<div class="form-group">
							<label>Inventori ID</label>
							<input type='text' class="form-control" name="inventori_id" value="<?php echo $data_cek['inventori_id']; ?>"
							/>
						</div>

						<div class="form-group">
							<label>Nama Alat</label>
							<input type='text' class="form-control" name="nama_alat" value="<?php echo $data_cek['nama_alat']; ?>"
							/>
						</div>

						<div class="form-group">
							<label>Owning</label>
							<input class="form-control" name="owning" value="<?php echo $data_cek['owning']; ?>"
							/>
						</div>

						<div class="form-group">
							<label>Lokasi</label>
							<input class="form-control" name="lokasi" value="<?php echo $data_cek['lokasi']; ?>">
						</div>

						<div class="form-group">
							<label>Jumlah</label>
							<input type='number' class="form-control" name="jumlah" value="<?php echo $data_cek['jumlah']; ?>">
						</div>

						<div class="form-group">
							<label>Tgl Input</label>
							<input type='date' class="form-control" name="tgl_input" value="<?php echo $data_cek['tgl_input']; ?>">
						</div>

					</div>
					<!-- /.box-body -->

					<div class="box-footer">
						<input type="submit" name="Ubah" value="Ubah" class="btn btn-success">
						<a href="?page=MyApp/data_alat" class="btn btn-warning">Batal</a>
					</div>
				</form>
			</div>
			<!-- /.box -->
</section>

<?php

if (isset ($_POST['Ubah'])){
    //mulai proses ubah
    $sql_ubah = "UPDATE tb_alat SET
        inventori_id='".$_POST['inventori_id']."',
        nama_alat='".$_POST['nama_alat']."',
		owning='".$_POST['owning']."',
		lokasi='".$_POST['lokasi']."',
		jumlah='".$_POST['jumlah']."',
        tgl_input='".$_POST['tgl_input']."'
        WHERE id_alat='".$_POST['id_alat']."'";
    $query_ubah = mysqli_query($koneksi, $sql_ubah);

    if ($query_ubah) {
        echo "<script>
        Swal.fire({title: 'Ubah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
        }).then((result) => {
            if (result.value) {
                window.location = 'index.php?page=MyApp/data_alat';
            }
        })</script>";
        }else{
        echo "<script>
        Swal.fire({title: 'Ubah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
        }).then((result) => {
            if (result.value) {
                window.location = 'index.php?page=MyApp/data_alat';
            }
        })</script>";
    }
}

