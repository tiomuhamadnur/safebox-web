<?php
    //Mulai Sesion
    session_start();
    if (isset($_SESSION["ses_username"])==""){
		header("location: login.php");
    
    }else{
      $data_id = $_SESSION["ses_id"];
      $data_nama = $_SESSION["ses_nama"];
      $data_user = $_SESSION["ses_username"];
      $data_level = $_SESSION["ses_level"];
    }

    //KONEKSI DB
    include "inc/koneksi.php";
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>TCSM InSys</title>
	<link rel="icon" href="loginform/images/mm.png">
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<!-- Select2 -->
	<link rel="stylesheet" href="plugins/select2/select2.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
	<!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
	<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>

<body class="hold-transition skin-blue sidebar-mini">
	<!-- Site wrapper -->
	<div class="wrapper">

		<header class="main-header">
			<!-- Logo -->
			<a href="index.php" class="logo">
				<span class="logo-lg">
					<img src="dist/img/AAA.png" width="50px">
					<b>TCSM InSys</b>
				</span>
			</a>
			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>

				<div class="navbar-custom-menu">
					<ul class="nav navbar-nav">
						<!-- Messages: style can be found in dropdown.less-->
						<li class="dropdown messages-menu">
							<a class="dropdown-toggle">
								<span>
									<b>
										TCSM INVENTORY SYSTEM V1.0
									</b>
								</span>
							</a>
						</li>
					</ul>
				</div>
			</nav>
		</header>

		<!-- =============================================== -->

		<!-- Left side column. contains the sidebar -->
		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				</<b>
				<div class="user-panel">
					<div class="pull-left image">
						<img src="dist/img/ff.png" class="img-circle" alt="User Image">
					</div>
					<div class="pull-left info">
						<p>
							<?php echo $data_nama; ?>
						</p>
						<span class="label label-warning">
							<?php echo $data_level; ?>
						</span>
					</div>
				</div>
				</br>
				<!-- /.search form -->
				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu">
					<li class="header">MENU NAVIGATION</li>

					<!-- Level  -->
					<?php
          if ($data_level=="Administrator"){
        ?>

					<li class="treeview">
						<a href="?page=admin">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-folder"></i>
							<span>Kelola Data</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">

							<li>
								<a href="?page=MyApp/data_alat">
									<i class="fa fa-book"></i>Data Alat</a>
							</li>
							<li>
								<a href="?page=MyApp/data_agt">
									<i class="fa fa-users"></i>Data Tim</a>
							</li>
						</ul>
					</li>

					<li class="treeview">
						<a href="?page=data_sirkul">
							<i class="fa fa-refresh"></i>
							<span>Pengajuan</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-book"></i>
							<span>Log Data</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">

							<li>
								<a href="?page=log_pinjam">
									<i class="fa fa-arrow-circle-o-down"></i>Peminjaman</a>
							</li>
							<li>
								<a href="?page=log_kembali">
									<i class="fa fa-arrow-circle-o-up"></i>Pengembalian</a>
							</li>
						</ul>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-print"></i>
							<span>Report</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li>
								<a href="report/laporan_alat.php" target="blank">
									<i class="fa fa-file"></i>Report Alat</a>
							</li>
							<li>
								<a href="report/laporan_tim.php" target="blank">
									<i class="fa fa-file"></i>Report List Tim</a>
							</li>
							<li>
								<a href="report/laporan_pinjam.php" target="blank">
									<i class="fa fa-file"></i>Report Peminjaman</a>
							</li>
							<li>
								<a href="report/laporan_kembali.php" target="blank">
									<i class="fa fa-file"></i>Report Pengembalian</a>
							</li>
						</ul>
					</li>


					<li class="header">SETTING</li>

					<li class="treeview">
						<a href="?page=MyApp/data_user">
							<i class="fa fa-user"></i>
							<span>User Sistem</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>

					<?php
          } elseif($data_level=="User"){
        ?>

					<li class="treeview">
						<a href="?page=user">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-folder"></i>
							<span>Kelola Data</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">

							<li>
								<a href="?page=MyApp/data_alat">
									<i class="fa fa-book"></i>Data Alat</a>
							</li>
							<li>
								<a href="?page=MyApp/data_agt">
									<i class="fa fa-users"></i>Data List Tim</a>
							</li>
						</ul>
					</li>

					<li class="treeview">
						<a href="?page=data_sirkul">
							<i class="fa fa-refresh"></i>
							<span>Transaksi</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-book"></i>
							<span>Log Data</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">

							<li>
								<a href="?page=log_pinjam">
									<i class="fa fa-arrow-circle-o-down"></i>Peminjaman</a>
							</li>
							<li>
								<a href="?page=log_kembali">
									<i class="fa fa-arrow-circle-o-up"></i>Pengembalian</a>
							</li>
						</ul>
					</li>

					<li class="treeview">
						<a href="#">
							<i class="fa fa-print"></i>
							<span>Report</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li>
								<a href="report/laporan_alat.php" target="blank">
									<i class="fa fa-file"></i>Report Alat</a>
							</li>
							<li>
								<a href="report/laporan_tim.php" target="blank">
									<i class="fa fa-file"></i>Report List Tim</a>
							</li>
							<li>
								<a href="report/laporan_pinjam.php" target="blank">
									<i class="fa fa-file"></i>Laporan Peminjaman</a>
							</li>
							<li>
								<a href="report/laporan_kembali.php" target="blank">
									<i class="fa fa-file"></i>Report Pengembalian</a>
							</li>
						</ul>
					</li>

					<li class="header">SETTING</li>

					<?php
						}
					?>

					<li>
						<a href="logout.php" onclick="return confirm('Apakah Anda yakin keluar dari TCSM InSys?')">
							<i class="fa fa-sign-out"></i>
							<span>Logout</span>
							<span class="pull-right-container"></span>
						</a>
					</li>


			</section>
			<!-- /.sidebar -->
		</aside>

		<!-- =============================================== -->

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<?php 
      if(isset($_GET['page'])){
          $hal = $_GET['page'];
  
          switch ($hal) {
              //Klik Halaman Home user
              case 'admin':
                  include "home/admin.php";
                  break;
              case 'user':
                  include "home/user.php";
                  break;
        
              //user
              case 'MyApp/data_user':
                  include "admin/user/data_user.php";
                  break;
              case 'MyApp/add_user':
                  include "admin/user/add_user.php";
                  break;
              case 'MyApp/edit_user':
                  include "admin/user/edit_user.php";
                  break;
              case 'MyApp/del_user':
                  include "admin/user/del_user.php";
				  break;
				  

              //agt
              case 'MyApp/data_agt':
                  include "admin/agt/data_agt.php";
                  break;
              case 'MyApp/add_agt':
                  include "admin/agt/add_agt.php";
                  break;
              case 'MyApp/edit_agt':
                  include "admin/agt/edit_agt.php";
                  break;
              case 'MyApp/del_agt':
                  include "admin/agt/del_agt.php";
                  break;

              //alat
              case 'MyApp/data_alat':
                  include "admin/alat/data_alat.php";
                  break;
              case 'MyApp/add_alat':
                  include "admin/alat/add_alat.php";
                  break;
              case 'MyApp/edit_alat':
                  include "admin/alat/edit_alat.php";
                  break;
              case 'MyApp/del_alat':
                  include "admin/alat/del_alat.php";
				  break;
				  
				//sirkul
              case 'data_sirkul':
                  include "admin/sirkul/data_sirkul.php";
                  break;
              case 'add_sirkul':
                  include "admin/sirkul/add_sirkul.php";
                  break;
              case 'panjang':
                  include "admin/sirkul/panjang.php";
                  break;
              case 'kembali':
                  include "admin/sirkul/kembali.php";
				  break;

				//log
				case 'log_pinjam':
					include "admin/log/log_pinjam.php";
					break;
				case 'log_kembali':
					include "admin/log/log_kembali.php";
					break;

				//laporan
				case 'laporan':
					include "user/laporan/view_laporan.php";
					break;
             

          
              //default
              default:
				  echo "<center><br><br><br><br><br><br><br><br><br>
				  <h1> Halaman tidak ditemukan !</h1></center>";
                  break;    
          }
      }else{
        // Auto Halaman Home user
          if($data_level=="Administrator"){
              include "home/admin.php";
              }
                  elseif($data_level=="User"){
                      include "home/user.php";
                      }
                        }
    ?>



			</section>
			<!-- /.content -->
		</div>

		<!-- /.content-wrapper -->

		<footer class="main-footer">
			<div class="pull-right hidden-xs">
			</div>
			<strong>Copyright &copy;
				<a href="https://www.instagram.com/tideupindustries/">TIDE UP INDUSTRIES</a>.</strong> All rights reserved.
		</footer>
		<div class="control-sidebar-bg"></div>

		<!-- ./wrapper -->

		<!-- jQuery 2.2.3 -->
		<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
		<!-- Bootstrap 3.3.6 -->
		<script src="bootstrap/js/bootstrap.min.js"></script>

		<script src="plugins/select2/select2.full.min.js"></script>
		<!-- DataTables -->
		<script src="plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>

		<!-- AdminLTE App -->
		<script src="dist/js/app.min.js"></script>
		<!-- AdminLTE for demo purposes -->
		<script src="dist/js/demo.js"></script>
		<!-- page script -->


		<script>
			$(function() {
				$("#example1").DataTable();
				$('#example2').DataTable({
					"paging": true,
					"lengthChange": false,
					"searching": false,
					"ordering": true,
					"info": true,
					"autoWidth": false
				});
			});
		</script>

		<script>
			$(function() {
				//Initialize Select2 Elements
				$(".select2").select2();
			});
		</script>
</body>

</html>